from aerius_connection import AeriusConnection

ac = AeriusConnection(api_key='5328da4be7414928ad979282e226f7bb')
print(ac)
